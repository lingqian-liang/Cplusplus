//
//  main.cpp
//  Project_Team3_Tuesday
//
//  Created by LIANGLINQIAN on 2017/12/12.
//  Copyright © 2017年 LIANGLINQIAN. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
